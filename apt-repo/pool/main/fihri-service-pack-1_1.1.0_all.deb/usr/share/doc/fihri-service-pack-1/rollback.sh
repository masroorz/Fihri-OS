#!/bin/bash
# /usr/share/doc/fihri-service-pack-1/rollback.sh
# Roll back Fihri OS Service Pack 1 (fihri-service-pack-1) to pre-SP1 state:
#  - Restores .bak-sp1 backups of canlinux-update-guard, canlinux-dde-heal,
#    canlinux-dde-selftest, freerdp-shadow-start.sh, /etc/skel/.config/deepin-kwinrc,
#    each user's ~/.config/deepin-kwinrc, /opt/canlinux-repo metadata, and /etc/apt/sources.list.d.
#  - Downgrades the 8 SP1 packages back to their pre-SP1 versions from /opt/canlinux-repo/pool/main/d/
#    (1.0.4-3+canlinux15, 1.0.10-1+canlinux9.2, 1.0.10-2) and re-applies apt-mark hold.
#  - Removes fihri-service-pack-1 package cleanly and reloads desktop shell.
set -euo pipefail

if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: rollback.sh must be run as root (use sudo)." >&2
    exit 1
fi

export LC_ALL=C
export DEBIAN_FRONTEND=noninteractive
export NEEDRESTART_MODE=l
export NEEDRESTART_SUSPEND=1

BACKUP_ROOT="/var/backups/fihri-service-pack-1"
REPO_ROOT="/opt/canlinux-repo"
POOL_MAIN="$REPO_ROOT/pool/main"

echo "[rollback] Starting Fihri OS Service Pack 1 rollback..."

rm -f /etc/apt/apt.conf.d/97fihri-sp1-finish /run/fihri-sp1-pending 2>/dev/null || true

# 1. Remove fihri-service-pack-1 package first (if installed) so dpkg releases ownership
if dpkg -s fihri-service-pack-1 >/dev/null 2>&1; then
    echo "[rollback] Removing fihri-service-pack-1 package..."
    dpkg --purge fihri-service-pack-1 >/dev/null 2>&1 || dpkg -r fihri-service-pack-1 >/dev/null 2>&1 || true
fi

# 2. Restore system scripts and skel config from .bak-sp1 or /var/backups/fihri-service-pack-1
for f in /usr/local/sbin/canlinux-update-guard \
         /usr/local/sbin/canlinux-dde-heal \
         /usr/local/sbin/canlinux-dde-selftest \
         /usr/local/sbin/canlinux-regress-watch \
         /usr/local/bin/freerdp-shadow-start.sh \
         /etc/skel/.config/deepin-kwinrc; do
    if [ -f "${f}.bak-sp1" ]; then
        cp -a "${f}.bak-sp1" "$f"
        rm -f "${f}.bak-sp1"
        echo "[rollback] Restored $f from ${f}.bak-sp1"
    elif [ -f "$BACKUP_ROOT/$(basename "$f").bak-sp1" ]; then
        cp -a "$BACKUP_ROOT/$(basename "$f").bak-sp1" "$f"
        echo "[rollback] Restored $f from $BACKUP_ROOT/$(basename "$f").bak-sp1"
    fi
done
if [ -x /usr/local/sbin/canlinux-regress-watch ]; then
    /usr/local/sbin/canlinux-regress-watch --rebaseline >/dev/null 2>&1 || true
fi

# 3. Restore /opt/canlinux-repo metadata backups and remove staged SP1 .debs
for rf in Packages Packages.gz Release; do
    if [ -f "$BACKUP_ROOT/repo/${rf}.bak-sp1" ]; then
        cp -a "$BACKUP_ROOT/repo/${rf}.bak-sp1" "$REPO_ROOT/$rf"
        echo "[rollback] Restored $REPO_ROOT/$rf"
    fi
done

# 4. Restore per-user ~/.config/deepin-kwinrc
while IFS=: read -r uname _pw uid _gid _gecos uhome _shell; do
    [ "$uid" -ge 1000 ] 2>/dev/null && [ "$uid" -lt 65534 ] || continue
    [ -d "$uhome" ] || continue
    kw="$uhome/.config/deepin-kwinrc"
    if [ -f "${kw}.bak-sp1" ]; then
        cp -a "${kw}.bak-sp1" "$kw"
        rm -f "${kw}.bak-sp1"
        echo "[rollback] Restored $kw"
    elif [ -f "$BACKUP_ROOT/users/${uname}.deepin-kwinrc.bak-sp1" ]; then
        cp -a "$BACKUP_ROOT/users/${uname}.deepin-kwinrc.bak-sp1" "$kw"
        echo "[rollback] Restored $kw from backup"
    elif [ -f "$BACKUP_ROOT/users/${uname}.absent" ]; then
        rm -f "$kw"
        rm -f "$BACKUP_ROOT/users/${uname}.absent"
        echo "[rollback] Removed $kw (was absent prior to SP1)"
    fi
done < /etc/passwd

# 5. Remove GitHub APT feed & keyring (and restore sources.list.d backups if needed)
rm -f /etc/apt/sources.list.d/fihri-updates.list \
      /etc/apt/sources.list.d/fihri-os.list \
      /etc/apt/apt.conf.d/20fihri-periodic-update \
      /etc/needrestart/conf.d/50-fihri-sp1.conf \
      /usr/share/keyrings/fihri-updates.gpg \
      /usr/share/keyrings/fihri-os-archive-keyring.gpg 2>/dev/null || true
if [ -d "$BACKUP_ROOT/sources.list.d" ]; then
    for sf in "$BACKUP_ROOT/sources.list.d"/*; do
        [ -f "$sf" ] || continue
        cp -a "$sf" "/etc/apt/sources.list.d/$(basename "$sf")"
    done
fi

# 5b. Restore Netplan 10-canlinux-live-ethernet.yaml backups if present
if [ -f "$BACKUP_ROOT/usr-lib-10-canlinux-live-ethernet.yaml.bak-sp1" ]; then
    install -o root -g root -m 0600 "$BACKUP_ROOT/usr-lib-10-canlinux-live-ethernet.yaml.bak-sp1" /usr/lib/canlinux/netplan/10-canlinux-live-ethernet.yaml || true
fi
if [ -f "$BACKUP_ROOT/etc-netplan-10-canlinux-live-ethernet.yaml.bak-sp1" ]; then
    install -o root -g root -m 0600 "$BACKUP_ROOT/etc-netplan-10-canlinux-live-ethernet.yaml.bak-sp1" /etc/netplan/10-canlinux-live-ethernet.yaml || true
fi
command -v netplan >/dev/null 2>&1 && netplan generate || true
command -v udevadm >/dev/null 2>&1 && udevadm control --reload-rules || true
command -v nmcli >/dev/null 2>&1 && nmcli connection reload || true

# 6. Downgrade SP1 packages back to pre-SP1 versions from /opt/canlinux-repo/pool/main/d
SP1_PKGS=(
    "dde-tray-loader"
    "dde-tray-loader-dev"
    "deepin-service-plugin-network"
    "dde-shell"
    "dde-shell-example"
    "libdde-shell"
    "libdde-shell-dev"
    "dde-launchpad"
)
apt-mark -o Debug::NoLocking=1 unhold "${SP1_PKGS[@]}" dde-clipboard libdde-network-core libdde-network-core-dev dcc-network-plugin >/dev/null 2>&1 || true
dpkg --purge dde-clipboard dcc-network-plugin libdde-network-core-dev libdde-network-core ipheth-utils libimobiledevice-utils >/dev/null 2>&1 || true

# 1.1.0: restore pre-SP1 bluetooth state + remove hci bring-up units
[ -f /etc/bluetooth/main.conf.bak-sp1 ] && cp -a /etc/bluetooth/main.conf.bak-sp1 /etc/bluetooth/main.conf || true
rm -f /lib/udev/rules.d/99-fihri-bt-hciup.rules /usr/lib/udev/rules.d/99-fihri-bt-hciup.rules \
      /lib/systemd/system/fihri-bt-power-on@.service /usr/lib/systemd/system/fihri-bt-power-on@.service \
      /usr/local/sbin/fihri-bt-power-on /usr/share/applications/canlinux-widgets-toggle.desktop \
      /usr/local/share/applications/canlinux-widgets-toggle.desktop 2>/dev/null || true
command -v udevadm >/dev/null 2>&1 && udevadm control --reload-rules >/dev/null 2>&1 || true
command -v systemctl >/dev/null 2>&1 && systemctl daemon-reload >/dev/null 2>&1 || true

ROLLBACK_DEBS=()
for d in "$POOL_MAIN/d/dde-tray-loader/dde-tray-loader_1.0.4-3+canlinux15_amd64.deb" \
         "$POOL_MAIN/d/dde-tray-loader/dde-tray-loader-dev_1.0.4-3+canlinux15_amd64.deb" \
         "$POOL_MAIN/d/dde-tray-loader/deepin-service-plugin-network_1.0.4-3+canlinux15_amd64.deb" \
         "$POOL_MAIN/d/dde-tray-loader/dde-tray-loader_1.0.4-3+canlinux18_amd64.deb" \
         "$POOL_MAIN/d/dde-tray-loader/dde-tray-loader-dev_1.0.4-3+canlinux18_amd64.deb" \
         "$POOL_MAIN/d/dde-tray-loader/deepin-service-plugin-network_1.0.4-3+canlinux18_amd64.deb" \
         "$POOL_MAIN/d/dde-shell/dde-shell_1.0.10-1+canlinux9.2_amd64.deb" \
         "$POOL_MAIN/d/dde-shell/dde-shell-example_1.0.10-1+canlinux9.2_amd64.deb" \
         "$POOL_MAIN/d/dde-shell/libdde-shell_1.0.10-1+canlinux9.2_amd64.deb" \
         "$POOL_MAIN/d/dde-shell/libdde-shell-dev_1.0.10-1+canlinux9.2_amd64.deb" \
         "$POOL_MAIN/d/dde-launchpad/dde-launchpad_1.0.10-2_amd64.deb"; do
    [ -f "$d" ] && ROLLBACK_DEBS+=("$d")
done

if [ "${#ROLLBACK_DEBS[@]}" -gt 0 ]; then
    echo "[rollback] Restoring pre-SP1 packages from $POOL_MAIN..."
    dpkg -i --force-downgrade "${ROLLBACK_DEBS[@]}" || true
fi

# If dde-launchpad 1.0.10-2 was not in local pool, downgrade from UbuntuDDE PPA if reachable
if [ "$(dpkg-query -W -f='${Version}' dde-launchpad 2>/dev/null || true)" != "1.0.10-2" ]; then
    rm -f "$POOL_MAIN/d/dde-launchpad"/dde-launchpad_1.0.10-2+canlinux*.deb 2>/dev/null || true
    apt-get install -y --allow-downgrades --allow-change-held-packages dde-launchpad=1.0.10-2 >/dev/null 2>&1 || true
fi

apt-mark -o Debug::NoLocking=1 hold "${SP1_PKGS[@]}" >/dev/null 2>&1 || true

# Run guard to verify restored state
if [ -x /usr/local/sbin/canlinux-update-guard ]; then
    /usr/local/sbin/canlinux-update-guard || true
fi

# 7. Reload desktop shell for active sessions
if command -v loginctl >/dev/null 2>&1; then
    while read -r sid uid user _rest; do
        [ -n "$sid" ] || continue
        state=$(loginctl show-session "$sid" -p State --value 2>/dev/null || true)
        class=$(loginctl show-session "$sid" -p Class --value 2>/dev/null || true)
        [ "$state" = "active" ] && [ "$class" = "user" ] || continue
        if [ -S "/run/user/$uid/bus" ]; then
            sudo -n -u "$user" env DISPLAY=:0 XDG_RUNTIME_DIR="/run/user/$uid" \
                DBUS_SESSION_BUS_ADDRESS="unix:path=/run/user/$uid/bus" \
                gdbus call --session --dest org.kde.KWin --object-path /KWin \
                --method org.kde.KWin.reconfigure >/dev/null 2>&1 || true
            sudo -n -u "$user" env XDG_RUNTIME_DIR="/run/user/$uid" \
                DBUS_SESSION_BUS_ADDRESS="unix:path=/run/user/$uid/bus" \
                systemctl --user restart dde-shell@DDE.service >/dev/null 2>&1 || true
        fi
    done < <(loginctl list-sessions --no-legend 2>/dev/null || true)
fi

echo "[rollback] Fihri OS Service Pack 1 rollback complete."
exit 0
